from voice.retrieval.vectorstore import vectorstore
from voice.retrieval.filters import build_filter

def search_schemes(query, state=None, government_level=None, k=2):
    query_filter = build_filter(government_level=government_level, state=state)
    docs = vectorstore.similarity_search(query, k=k, filter=query_filter)
    return docs