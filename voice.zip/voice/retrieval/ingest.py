"""
ingest.py — one-time (or whenever-the-dataset-changes) ingestion script.

Loads all schemes from schemes_rebuilt.jsonl and writes them into Qdrant
via QdrantVectorStore.from_documents(), which creates the collection AND
embeds/uploads the documents in one call. Not part of the live pipeline —
run this manually, not on every call.
"""

import os
from dotenv import load_dotenv
from langchain_qdrant import QdrantVectorStore, RetrievalMode

from voice.retrieval.embeddings import embeddings, sparse_embeddings
from voice.retrieval.loader import loader


load_dotenv()

os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "1"
qdrant_url = os.getenv("QDRANT_URL")
qdrant_api_key = os.getenv("QDRANT_API_KEY")
collection_name = "sarkari-schemes-voice"


def main():
    print("Loading documents from schemes_rebuilt.jsonl...")
    docs = loader.load()
    print(f"Loaded {len(docs)} documents.")

    print("Embedding and uploading to Qdrant (this creates the collection if it doesn't exist)...")
    QdrantVectorStore.from_documents(
        docs,
        embedding=embeddings,
        sparse_embedding=sparse_embeddings,
        retrieval_mode=RetrievalMode.HYBRID,
        url=qdrant_url,
        api_key=qdrant_api_key,
        collection_name=collection_name,
        vector_name="dense",
        sparse_vector_name="bm25",
    )

    print(f"Done. Ingested {len(docs)} documents into '{collection_name}'.")


if __name__ == "__main__":
    main()



